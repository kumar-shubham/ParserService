package com.pisight.pimoney1.beans;

import java.util.HashMap;
import java.util.TreeMap;

import com.asprise.ocr.Ocr;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ocr.main(args);
		
		
		
		
		
		

	}

}
