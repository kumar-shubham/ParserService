package com.pisight.pimoney1.beans;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.http.impl.io.IdentityOutputStream;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.ImageIOUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pisight.pimoney1.beans.CardAccount;
import com.pisight.pimoney1.beans.CardTransaction;
import com.pisight.pimoney1.beans.ParserUtility;

public class PDFTest {

	private static HashSet<String> descriptionDebit = new HashSet<String>();
	private static HashSet<String> descriptionCredit = new HashSet<String>();

	public static final String TABLE_ID					=	"PDF_TO_HTML";

	private static final String TABLE_OPENING			=	"<table id=\""+TABLE_ID+"\"><tbody><tr><td>";

	private static final String TABLE_CLOSING			=	"</td></tr></tbody></table>";

	private static final String LINE_SEPARATOR			=	"</td></tr><tr><td>";

	static{
		descriptionCredit.add("salary");
		descriptionCredit.add("earned");
		descriptionCredit.add("disbursement");

		descriptionDebit.add("transaction");
		descriptionDebit.add("withdrawal");
		descriptionDebit.add("bill payment");
		descriptionDebit.add("funds transfer");

	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		//		Path p = Paths.get(System.getProperty("user.home"), ".m2", "chromedriver.exe");

		//		sSystem.setProperty("webdriver.chrome.driver",p.toString() );

		WebDriver driver = getDriver();


		JavascriptExecutor js = (JavascriptExecutor) driver;

		//		String page = getHTMLFromPDF();

		String page = getHTMLFromImage();

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~``");
		//		System.out.println(page);

		js.executeScript(page);
		scrapeStatement(driver);
		System.out.println("closing driver");

		driver.quit();

	}

	private static String getHTMLFromPDF() throws Exception{

		PDFExtracter pdfExtractor = null;
		try{
			pdfExtractor = new PDFExtracter(getFile("HDFC", "52913630_1475827655982", "pdf"), "KUMA1932");
		}catch(CryptographyException e){
			if(e.getMessage().contains("The supplied password does not match")){
				System.out.println("The supplied password does not match");
			}
			throw e;
		}

		BoxTest boxTest = null;
		try{
			boxTest = new BoxTest(getFile("AMEX", "Statement_Oct 2015", "pdf"), "");
		}catch(CryptographyException e){
			if(e.getMessage().contains("The supplied password does not match")){
				System.out.println("The supplied password does not match");
			}
			throw e;
		}

		String page = boxTest.convertPDFToHTML(" ");
		return page;
	}

	private static List<File> convertPDFtoImage(File file) throws IOException{

		PDDocument document = PDDocument.loadNonSeq(file, null);
		List<PDPage> pdPages = document.getDocumentCatalog().getAllPages();
		String path = file.getParent();
		System.out.println("path -> " + path);
		List<File> imageFiles = new ArrayList<File>();
		int page = 0;
		for (PDPage pdPage : pdPages)
		{ 
			++page;
			String filename = path + "/temp" + "-" + page + ".png";
			BufferedImage bim = pdPage.convertToImage(BufferedImage.TYPE_INT_RGB, 300);
			ImageIOUtil.writeImage(bim, filename, 300);
			imageFiles.add(new File(filename));

		}
		document.close();

		return imageFiles;

	}

	private static String getHTMLFromImage() throws IOException{

		File pdfFile = getFile("insurance", "Insurance (blankout)_2", "pdf");

		//		File pdfFile = getFile("CITI", "CITIMain", "pdf");

		List<File> imageFiles = convertPDFtoImage(pdfFile);

		String htmlCode = "";

		int count = 0;
		for(File file: imageFiles){
			count++;
			if(count == 3)
				htmlCode +=  LINE_SEPARATOR +  GoogleOCR.getHTML(file);
		}

		htmlCode = TABLE_OPENING + htmlCode + TABLE_CLOSING;

		System.out.println("page -> " + htmlCode);

		System.exit(0);
		String escapedJavaScripthtmlCode= StringEscapeUtils.escapeEcmaScript(htmlCode);
		StringBuilder sb = new StringBuilder();
		sb.append("var newHTML         = document.createElement ('table');");
		sb.append("newHTML.setAttribute('id','"+ TABLE_ID + "');");
		sb.append("var strVar=").append("\"").append(escapedJavaScripthtmlCode).append("\";");
		sb.append("newHTML.innerHTML=strVar;");
		sb.append("document.body.appendChild(newHTML);");
		return sb.toString();
	}

	private static File getFile(String dir, String name, String type) {
		// TODO Auto-generated method stub

		String fileName = dir + "/" + name + "." + type.toLowerCase();
		System.out.println("FFFFFFFFFFFFFFFFFFFFFF  ::: " + fileName);

		Path p = Paths.get(System.getProperty("user.home"), "Downloads/statements/statements", fileName);

		System.out.println("AAAAAAAAAAAA :: " + p.toString());

		return p.toFile();
	}

	private static WebDriver getDriver() {
		// TODO Auto-generated method stub
		Path p1 = Paths.get(System.getProperty("user.home"), "drivers", "phantomjs");

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setJavascriptEnabled(true);  
		caps.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY, p1.toString());

		WebDriver driver = new PhantomJSDriver(caps);

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		return driver;
	}

	public static void scrapeStatement(WebDriver driver) throws Exception{


		WebElement page = driver.findElement(By.id("PDF_TO_HTML"));

		CardAccount ca = new CardAccount();

		WebElement date1 = null;
		WebElement date2 = null;
		WebElement accNumEle = null;
		try{
			date1 = page.findElement(By.xpath("//td[contains(text(), 'Cardmember')]/../following-sibling::tr[1]"));
			date2 = page.findElement(By.xpath("//td[contains(text(), 'Cardmember')]/../following-sibling::tr[2]"));
			accNumEle = page.findElement(By.xpath("//td[contains(text(), 'Cardmember')]/../following-sibling::tr[3]"));
		}catch(NoSuchElementException e){
			System.out.println("Cardmember not found");
			date1 = page.findElement(By.xpath("//td[contains(text(), 'Due Date')]/../following-sibling::tr[2]"));
			date2 = page.findElement(By.xpath("//td[contains(text(), 'Due Date')]/../following-sibling::tr[3]"));
			accNumEle = page.findElement(By.xpath("//td[contains(text(), 'Due Date')]/../following-sibling::tr[4]"));
		}

		String stmtDate = date1.getText().replace(" ", "");
		String dueDate = date2.getText().replace(" ", "");
		String accNum = accNumEle.getText().trim();

		stmtDate = formatDate(stmtDate);
		dueDate = formatDate(dueDate);

		WebElement amount1 = null;
		WebElement amount2 = null;
		try{
			amount1 = page.findElement(By.xpath("//td[contains(text(), 'Available Cash Limit')]/../following-sibling::tr[1]"));
			amount2 = page.findElement(By.xpath("//td[contains(text(), 'Available Cash Limit')]/../following-sibling::tr[2]"));
		}
		catch(NoSuchElementException e){
			System.out.println("Available Cash Limit not found");
			amount1 = page.findElement(By.xpath("//td[contains(text(), 'able Credit Limit')]/../following-sibling::tr[2]"));
			amount2 = page.findElement(By.xpath("//td[contains(text(), 'able Credit Limit')]/../following-sibling::tr[3]"));
		}

		String creditLimit = amount1.getText().replace(" ", "");
		String availableLimit = amount2.getText().replace(" ", "");

		WebElement amount3 = null;
		WebElement amount4 = null;
		try{
			amount3 = page.findElement(By.xpath("//td[contains(text(), 'Total Dues')]/../following-sibling::tr[5]"));
		}
		catch(NoSuchElementException e){
			System.out.println("Total Dues not found");
			amount3 = page.findElement(By.xpath("//td[contains(text(), 'Purchase and Debits')]/../following-sibling::tr[5]"));
		}
		try{
			amount4 = page.findElement(By.xpath("//td[contains(text(), 'Minimum Amount Due')]/../following-sibling::tr[5]"));
		}
		catch(NoSuchElementException e){
			System.out.println("Minimum Amount Due");
			amount4 = page.findElement(By.xpath("//td[contains(text(), 'Current Dues')]/../following-sibling::tr[5]"));
		}

		String amountDue = amount3.getText().replace(" ", "");
		String minPayment = amount4.getText().replace(" ", "");

		amountDue = formatAmount(amountDue);
		minPayment = formatAmount(minPayment);


		ca.setAccountNumber(accNum);
		ca.setBillDate(stmtDate);
		ca.setDueDate(dueDate);
		ca.setTotalLimit(creditLimit);
		ca.setAvailableCredit(availableLimit);
		ca.setAmountDue(amountDue);
		ca.setMinAmountDue(minPayment);

		String dateRegex = " ?(\\d{2} ?. ?\\d{2} ?. ?\\d{2}) ?";
		String amountRegex = "(.* )?((\\d*,)*\\d+(\\.)\\d+( Cr)?)";

		Pattern pDate = Pattern.compile(dateRegex);
		Pattern pAmount = Pattern.compile(amountRegex);
		Matcher m = null;

		List<WebElement> transEle = page.findElements(By.xpath("//td[contains(text(), 'Amount')]/../following-sibling::tr"));

		if(transEle.size() == 0 || !transEle.get(0).getText().contains("Merchant")){
			transEle = page.findElements(By.xpath("//td[contains(text(), 'Merchant')]/../following-sibling::tr"));
		}

		CardTransaction lastTrans = null;
		for(WebElement ele: transEle){

			String text = ele.getText().trim();

			m = pDate.matcher(text);

			if(m.matches()){
				CardTransaction ct = new CardTransaction();
				String transDate = m.group(1);
				transDate = formatDate(transDate);

				ct.setTransDate(transDate);
				ct.setAccountNumber(accNum);
				ct.setCurrency("INR");
				lastTrans = ct;
			}
			else{

				if(lastTrans != null){
					m = pAmount.matcher(text);
					if(m.matches()){
						String amount = m.group(2);
						String transType = null;
						String desc = lastTrans.getDescription();
						if(amount.toLowerCase().contains("cr")){
							transType = CardTransaction.TRANSACTION_TYPE_CREDIT;
							if(desc == null || desc.equals("")){
								lastTrans.setDescription("credit");
							}
						}
						else{
							transType = CardTransaction.TRANSACTION_TYPE_DEBIT;
							if(desc == null || desc.equals("")){
								lastTrans.setDescription("debit");
							}
						}
						amount = amount.replace("Cr", "");
						amount = amount.replace("CR", "");
						lastTrans.setAmount(amount);
						lastTrans.setTransactionType(transType);
						ca.addTransaction(lastTrans);
						lastTrans = null;
					}
					else{
						String desc = lastTrans.getDescription() + " " + text;
						lastTrans.setDescription(desc.trim());
					}
				}
			}

			if(text.toLowerCase().contains("reward points") || text.toLowerCase().contains("opening balance")){
				break;
			}
		}




		ObjectMapper mapper = new ObjectMapper();
		Path p3 = Paths.get(System.getProperty("user.home"), "Documents", "bankStmt.json");
		try {
			mapper.writeValue(new File(p3.toString()), ca);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}




	}

	private static String formatDate(String date){

		date = date.replace("/", "");
		date = date.replace(" ", "");

		if(date.length() == 6){

			date = date.substring(0, 2) + "-" + date.substring(2,4) + "-20" + date.substring(4); 
		}
		else if(date.length() == 8){
			date = date.substring(0, 2) + "-" + date.substring(2,4) + "-" + date.substring(4); 
		}

		return date;
	}

	private static String formatAmount(String amount){

		if(!amount.contains(".")){
			amount = amount.substring(0,amount.length()-2) + "." + amount.substring(amount.length()-2);
		}
		return amount;
	}


}
