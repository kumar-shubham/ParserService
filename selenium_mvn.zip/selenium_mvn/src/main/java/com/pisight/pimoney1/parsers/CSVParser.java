package com.pisight.pimoney1.parsers;

public abstract class CSVParser implements Parser {

}
